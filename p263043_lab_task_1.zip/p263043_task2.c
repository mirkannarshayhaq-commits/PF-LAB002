#include <stdio.h>
int main(){
int a =2026;
char b =('B');
float c =62.67;
double d =268500;

printf("=======================================================\n");
printf("\t\tFAST-NUCES STUDENT PROFILE CARD\t\t\n");
printf("========================================================\n");
printf("Batch Year:\t %d\n",a);
printf("section:\t%c\n",b);
printf("Test Score:\t%f\n",c);
printf("Semister Fee:\t%1f\n",d);
printf("Motto:\tSmall daily steps leads to big sucess\n");
printf("=========================================================");

return 0;

}

